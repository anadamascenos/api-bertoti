package com.cadastro.api3semestre;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Api3semestreApplication {

	public static void main(String[] args) {
		SpringApplication.run(Api3semestreApplication.class, args);
	}

}
