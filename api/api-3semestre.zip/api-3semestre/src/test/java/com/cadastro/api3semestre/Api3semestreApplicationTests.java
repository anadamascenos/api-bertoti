package com.cadastro.api3semestre;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Api3semestreApplicationTests {

	@Test
	void contextLoads() {
	}

}
